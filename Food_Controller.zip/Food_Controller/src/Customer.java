import java.util.*;
import org.javatuples.Triplet; 
public class Customer {
	
	private String name;
	private String username,password;
	private Map<String,Integer> map=new HashMap<String,Integer>();
	private Scanner sc;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public String getname() {
		return name;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void login(LinkedList<hotel> v)
	{
		
		hotel h1;
		sc=new Scanner(System.in);
		System.out.println("List of Hotels: ");
		for(hotel h:v)
		{
			System.out.println(h.getname());
			
		}
		System.out.println("Choose hotel ie enter name");
		String name=sc.next();
		for(hotel h:v)
		{
			if(h.getname().equals(name))
			{
				order(h);
			}
			
		}
		
	}
	public void order(hotel h)
	{
		sc=new Scanner(System.in);
		System.out.println("Welcome to "+h.getname());
		ArrayList<Triplet<String,Integer,Integer> > arr=new ArrayList<Triplet<String,Integer,Integer> > ();
		//name,cost,quantity
		h.display_menu();
		boolean x=true;
		while(x)
		{
			int ch;
			System.out.println("1. Add items to cart 2.display cart 3.delete items 4.checkout");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:
			{
				String s;
				int c,q;
				System.out.println("Enter item name ");
				s=sc.nextLine();
				s=sc.nextLine();
				System.out.println("Enter item quantity");
				q=sc.nextInt();
				c=h.price(s);
				if(c==-1)
				{
					System.out.println("Item not found");
					break;
				}
				if(check(arr,s,q))
				{
					display_cart(arr);
					break;
				}
				Triplet<String,Integer,Integer>t=new Triplet<String,Integer,Integer>(s,c,q);
				arr.add(t);
				display_cart(arr);
				break;
			}
			case 2:
			{
				display_cart(arr);
				break;
			}
			case 3:
			{
				System.out.println("Enter the item t be deleted");
				String s;
				s=sc.nextLine();
				s=sc.nextLine();
				del(arr,s);
				System.out.println("----DEleted---");
				break;
				
			}
			case 4:
			{
				checkout(arr);
				return;
			}
			 
			
			}
			
		}
		
	}
	public boolean check(ArrayList<Triplet<String,Integer,Integer> > arr,String s,int q)
	{
		for(int i=0;i<arr.size();i++){
			if(arr.get(i).getValue0().equals(s))
			{
				int q1=arr.get(i).getValue2()+q;
				int c1=arr.get(i).getValue1();
				Triplet<String,Integer,Integer> w=new Triplet<String,Integer,Integer>(s,c1,q1);
				arr.remove(i);
				arr.add(w);
				return true;
			}
			
		}
		return false;
		
	}
	
	public void checkout(ArrayList<Triplet<String,Integer,Integer> > arr)
	{
		int total=0;
		System.out.println("******************RECIEPT********************");
		display_cart(arr);
		for(int i=0;i<arr.size();i++){
			total+=(arr.get(i).getValue1()*arr.get(i).getValue2());
		}
		System.out.println("--------------------------------------------------");
		System.out.println("Total: "+total);
		System.out.println("--------------------------------------------------");
		System.out.println("******************RECIEPT********************");
		
		
	}
	
	public void display_cart(ArrayList<Triplet<String,Integer,Integer> > arr)
	{
		
		for(int i=0;i<arr.size();i++){
			System.out.println("Name: " + arr.get(i).getValue0()+ " Price: " + arr.get(i).getValue1() + "  Quantity: " + arr.get(i).getValue2() + " Total dish price: " + arr.get(i).getValue1()*arr.get(i).getValue2() );
			
		}
	}
	public void del(ArrayList<Triplet<String,Integer,Integer> > arr,String s)
	{
		int p=-1;
		for(int i=0;i<arr.size();i++){
			if(arr.get(i).getValue0().equals(s))
			{
				arr.remove(i);
				return;
			}
			
		}
		
	}
	

}
