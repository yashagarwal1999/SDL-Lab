import java.util.*;
import java.io.*;
public class main_page {
	int whoo;
	
	public static void displayLinkedList(LinkedList<hotel> v)
	{
		for(hotel h:v)
		{
			System.out.println(h.getUsername()); h.display_menu();
		}
	}
	public static void main(String[] args)
	{
		LinkedList<hotel> v=new LinkedList<hotel>();
		Vector<Customer> cus=new Vector<Customer>();
		System.out.println("******************WELCOME TO FOOD DELIVERY SYSTEM********************");
		Scanner s=new Scanner(System.in);
		boolean x=true;
		while(x)
		{
			int c;
			System.out.println("1. Hotel owner 2.Customer 3.exit");
			c=s.nextInt();
			switch(c)
			{
			case 1:
			{
				int r;
				System.out.println("1. Register 2.Login");
				r=s.nextInt();
				if(r==1){
				String us,pass;
				System.out.println("Enter username");

				us=s.next();
				
				boolean flag=true;
				for(hotel h:v)
				{
					if(h.getUsername().equals(us))
					{
						flag=false;
						break;
					}
				}
				if(!flag)
				{
					System.out.println(" username Already exists");
					break;
				}
				else
				{
					hotel h1=new hotel();
					
					System.out.println(" Enter Password");
					pass=s.next();
					String nn;
					System.out.println(" Enter Name");
					nn=s.next();
					h1.setName(nn);

					h1.setUsername(us);
					h1.setPassword(pass);
					
					System.out.println(" Enter no of items to be inserted");
					int item,i;
					item=s.nextInt();
					for(i=0;i<item;i++)
						{
						h1.additem();
						}
					v.add(h1);
					displayLinkedList(v);

				}
				
				
				break;
				
				}
				else
				{
					System.out.println(" Enter username");
					String us=s.next();
					System.out.println(" Enter password");				
					String pass=s.next();
					boolean flag=false;
					for(hotel h:v)
					{
						if(h.getUsername().equals(us) && h.getPassword().equals(pass))
						{
							System.out.println("Welcome "+ h.getname() );
							flag=true;
							h.login();
							
							
							break;
						}
					}
					if(!flag)
					{
						System.out.println("Not found" );
					}
				}
				break;
				
			}
			case 2:
			{
				int r;
				System.out.println("1. Register 2.Login");
				r=s.nextInt();
				if(r==1){
				String us,pass;
				System.out.println("Enter Customer username");

				us=s.next();
				
				boolean flag=true;
				for(Customer h:cus)
				{
					if(h.getUsername().equals(us))
					{
						flag=false;
						break;
					}
				}
				if(!flag)
				{
					System.out.println(" Customer username Already exists");
					break;
				}
				else
				{
					Customer h1=new Customer();
					
					System.out.println(" Enter Customer Password");
					pass=s.next();
					String nn;
					System.out.println(" Enter Customer Name");
					nn=s.next();
					h1.setName(nn);

					h1.setUsername(us);
					h1.setPassword(pass);
					cus.add(h1);

					
					

				}
				
				
				break;
				
				}
				else
				{
					System.out.println(" Enter username");
					String us=s.next();
					System.out.println(" Enter password");				
					String pass=s.next();
					boolean flag=false;
					for(Customer h:cus)
					{
						if(h.getUsername().equals(us) && h.getPassword().equals(pass))
						{
							System.out.println("Welcome "+ h.getname() );
							flag=true;
							h.login(v);
							
							
							break;
						}
					}
					if(!flag)
					{
						System.out.println("Not found" );
					}
				}
				
				break;
			}
			case 3:
			{
				x=false;
				break;
			}
			
			}
			
		}
		
	s.close();
	}
	
	
	
	
	
}
