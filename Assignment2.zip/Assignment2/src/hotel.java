import java.util.*;
import java.io.*;
public class hotel implements Serializable{
	
	private String name;
	private String username,password;
	public Map<String,Integer> map;
	public Queue<String> q;
	private static Scanner scc;
	static
	{
		scc=new Scanner(System.in);
	}
	public hotel()
	{
		map=new HashMap<String,Integer>();
		q=new PriorityQueue<String>();
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public String getname() {
		return name;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void  additem()
	{
		String name,x;
		Integer cost;
		
		System.out.println("Enter Dish name");
		scc.nextLine();
		name=scc.nextLine();
		
		System.out.println("Enter price");
	
		cost=scc.nextInt();
	
		map.put(name,cost);
		display_menu();
		
		
	}
	public void display_menu()
	{
		
		for(Map.Entry<String,Integer> i:map.entrySet())
		{
			String key=(String)i.getKey();
			int val=(int)i.getValue();
			System.out.println("Dish name: "+key + " Price: "+ val);
		}
	}
	public void addorder(String s)
	{
		q.add(s);
	}
	
	
	public int price(String s)
	{
		for(Map.Entry<String,Integer> i:map.entrySet())
		{
			String key=(String)i.getKey();
			int val=(int)i.getValue();
			if(key.equals(s))
			{
				return val;
			}
		}
		return -1;
	}
	
	public void login()
	{
		boolean check=true;
		//scc=new Scanner(System.in);
		while(check)
		{
			System.out.println("1. Add item 2.display item 3.edit item 4.delete item  5.exit");
			int t=scc.nextInt();
			
			switch(t){
			case 1:
			{
				additem();
				break;
				
				
			}
			case 2:
			{
				display_menu();
				break; 
			}
			case 3:
			{
				String name;
				int cost;
			
				
				System.out.println("Enter Dish name");
				name=scc.next();
				System.out.println("Enter new price");
			
				cost=scc.nextInt();
				
				map.replace(name,cost);
				//scc.close();
				break;
			}
			case 4:
			{
				String name;
				
				
				
				System.out.println("Enter Dish name");
				name=scc.next();
				map.remove(name);
			
				break;
			}
//			case 6:
//			{
//				displayorder();
//				break;
//			}
			case 5:
			{
				check=false;
				
				return;
			}
			
			}
		}
	}
//	public void displayorder()
//	{
//		
//	}
	
	
	
	
	
	
}

