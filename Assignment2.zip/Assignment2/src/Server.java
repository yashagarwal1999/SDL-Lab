import java.net.*;
import java.util.*;
import java.io.*;
public class Server {
	static ObjectOutputStream dout;
	static ObjectInputStream din;
	static ServerSocket s1;
	static Socket soc;
	static LinkedList<hotel> v;
	static Scanner s;
	static Vector<Customer> cus;
	static
	{
		s=new Scanner(System.in);
		v=new LinkedList<hotel>();
		cus=new Vector<Customer>();
		try{
			 s1=new ServerSocket(23016);
			 soc=s1.accept();
			 din=new ObjectInputStream(soc.getInputStream());
			 dout=new ObjectOutputStream(soc.getOutputStream());
		}catch(Exception e){System.out.println(e.getMessage());}
	}
		public static void main(String args[])
		{
		try{
	
		
		//System.out.println(opt);
		boolean x=true;
		while(x)
		{
			String str="******************WELCOME TO FOOD DELIVERY SYSTEM********************";
			String option="1.Hotel 2.Customer 3.exit";
			dout.writeObject(str);
			dout.writeObject(option);
			//Scanner sc=new Scanner(System.in);
			int opt=(int)din.readObject();
			switch(opt)
			{
			case 1:
			{
				For_Hotel();
					
				break;
			}
			case 2:
			{
				For_Customer();
				
				break;
			}
			default:
			{
				x=false;
				break;
			}
			}
			
		}
		//din.close();
		//dout.close();
		
		}catch(Exception e){}
			
		}
		public static void For_Hotel() throws Exception
		{
			int c=(int)din.readObject();
			System.out.println(c);
			
			switch(c)
			{
			case 1:
			{
				hotel_register();
				break;
			}
			case 2:
			{
				hotel_login();
				break;
			}
			default:
			{
				System.out.println("Invalide option");
				return;
			}
			}
			
			
			
			
			}
		public static void hotel_login() throws Exception
		{
			String us,pass;
			us=(String)din.readObject();
			pass=(String)din.readObject();
			boolean flag=false;
			hotel de=new hotel();
			for(hotel h:v)
			{
				if(h.getUsername().equals(us) && h.getPassword().equals(pass))
				{
					String t="Welcome";
					de=h;
					dout.writeObject(t);
					dout.writeObject(h);
					flag=true;
					
					
					
					break;
				}
			}
			if(!flag)
			{
				String t="Not found";
				dout.writeObject(t);
			}
			hotel t=new hotel();
			t=(hotel)din.readObject();
			System.out.println("Logged out user is "+t.getUsername());
			boolean x=v.remove(de);
			v.add(t);
			
			displayLinkedList();
			
		}
		
		
		
		public static void hotel_register() throws Exception
		{
			String us,pass;
			us=(String)din.readObject();
			System.out.println(us);
			boolean flag=true;
			for(hotel h:v)
			{
				if(h.getUsername().equals(us))
				{
					flag=false;
					break;
				}
			}
			if(!flag)
			{
				int check=0;
				dout.writeObject(check);
			
				return;
			}
			else
			{
				int check=1;
				dout.writeObject(check);
				hotel h1=(hotel)din.readObject();
				v.add(h1);
				System.out.println("Registered user "+h1.getUsername());
				
				
			}
		


	
			
		}
		
		public static void For_Customer() throws Exception
		{

			int c=(int)din.readObject();
			System.out.println(c);
			
			switch(c)
			{
			case 1:
			{
				customer_register();
				break;
			}
			case 2:
			{
				customer_login();
				break;
			}
			default:
			{
				System.out.println("Invalide option");
				return;
			}
			}
			
			
			
			
		}
		
		public static void customer_login() throws ClassNotFoundException, IOException {
			
			String us,pass;
			us=(String)din.readObject();
			pass=(String)din.readObject();
			boolean flag=false;
			Customer de=new Customer();
			for(Customer h:cus)
			{
				if(h.getUsername().equals(us) && h.getPassword().equals(pass))
				{
					String t="Welcome";
					de=h;
					dout.writeObject(t);
					dout.writeObject(h);
					dout.writeObject(v);
					flag=true;
					
					
					
					break;
				}
			}
			if(!flag)
			{
				String t="Not found";
				dout.writeObject(t);
			}
			Customer t=new Customer();
			t=(Customer)din.readObject();
			System.out.println("Logged out user is "+t.getUsername());
			boolean x=v.remove(de);
			cus.add(t);
			
			
			
			
			
			
		}
		public static void customer_register() throws ClassNotFoundException, IOException {
			
			

			String us,pass;
			us=(String)din.readObject();
			System.out.println(us);
			boolean flag=true;
			for(Customer h:cus)
			{
				if(h.getUsername().equals(us))
				{
					flag=false;
					break;
				}
			}
			if(!flag)
			{
				int check=0;
				dout.writeObject(check);
			
				return;
			}
			else
			{
				int check=1;
dout.writeObject(check);
			Customer h1=(Customer)din.readObject();
				cus.add(h1);
				System.out.println("Registered customer "+h1.getUsername());
				
				
			}
			
		}
		public static void displayLinkedList()
		{
			for(hotel h:v)
			{
				System.out.println("THIS USERNAME "+h.getUsername()); 
				//h.display_menu();
			}
		}

}
