import java.util.*;
import java.net.*;
import java.io.*;
public class client {
	static Socket s;
	static ObjectOutputStream dout;
	static ObjectInputStream din;
	 static Scanner sc;
	static{
		 sc=new Scanner(System.in);
		try{
		 s=new Socket("localhost",23016);
		 dout=new ObjectOutputStream(s.getOutputStream());
		 din=new ObjectInputStream(s.getInputStream());
		
		}catch(Exception e){System.out.println(e.getMessage());}
	}
	public static void main(String args[])
	{
		try{
			
			
			
			boolean x=true;
			while(x)
			{
				String str=(String)din.readObject();
				String option=(String)din.readObject();
				System.out.println(str);
				System.out.println(option);
				int t;
				t=sc.nextInt();
				dout.writeObject(t);
				
				if(t==1)
				{
					for_hotel();
				}
				else if(t==2)
				{
					for_customer();
				}
				else
				{
					break;
				}
				
			//	int logopt=sc.nextInt();
				//dout.writeObject(logopt);
				
				
				
				
			}
			//din.close();
			//dout.close();
			
		}catch(Exception e){}
	}
	public static void for_hotel() throws ClassNotFoundException, IOException
	{
		
		String log="1. Register 2.Login";
		System.out.println(log);
		int choice=sc.nextInt();
		dout.writeObject(choice);
		
		switch(choice)
		{
		case 1:{
			String us,pass;
			System.out.println("Enter username");
			us=sc.next();
			dout.writeObject(us);
			String msg="username Already exists";
			String msg1="username available";
			//System.out.println(msg);
			int check=(int)din.readObject();
			hotel h1=new hotel();
			if(check==0)
			{
				System.out.println(msg);
				break;
				
			}
			System.out.println(msg1);
			
			
			System.out.println(" Enter Password");
			pass=sc.next();
			String nn;
			System.out.println(" Enter Name");
			nn=sc.next();
			h1.setName(nn);

			h1.setUsername(us);
			h1.setPassword(pass);
			//System.out.println(h1.getPassword()+"pass");
//			System.out.println(" Enter no of items to be inserted");
//			int item,i;
//			item=sc.nextInt();
//			for(i=0;i<item;i++)
//				{
//				h1.additem();
//				System.out.println("This is add");
//				}
				dout.writeObject(h1);
				break;
			
		}
		case 2:
		{
			String us,pass;
			System.out.println("Enter username");
			us=sc.next();
			System.out.println(" Enter Password");
			pass=sc.next();
			dout.writeObject(us);
			dout.writeObject(pass);
			String t=(String)din.readObject();
			//System.out.println(t);
			if(t.equals("Welcome"))
			{
				hotel h=new hotel();
				h=(hotel)din.readObject();
				System.out.println("Welcome "+h.getname());
				h.login();
				System.out.println("logged out on client side "+h.getUsername());
				dout.writeObject(h);
				
			}
			else
			{
				System.out.println(t);
			}
			
			break;
			
		}
		default:
		{
			break;
		}
		}
	}
	
	
	
	public static void for_customer() throws IOException, ClassNotFoundException
	{
		String log="1. Register 2.Login";
		System.out.println(log);
		int choice=sc.nextInt();
		dout.writeObject(choice);
		switch(choice)
		{
		case 1:
		{
			String us,pass;
			System.out.println("Enter username");
			us=sc.next();
			dout.writeObject(us);
			String msg="username Already exists";
			String msg1="username available";
			//System.out.println(msg);
			int check=(int)din.readObject();
			Customer h1=new Customer();
			if(check==0)
			{
				System.out.println(msg);
				break;
				
			}
			System.out.println(msg1);
			
			
			System.out.println(" Enter Password");
			pass=sc.next();
			String nn;
			System.out.println(" Enter Name");
			nn=sc.next();
			h1.setName(nn);

			h1.setUsername(us);
			h1.setPassword(pass);
			
				dout.writeObject(h1);
				break;
			
		}
		case 2:
		{

			String us,pass;
			System.out.println("Enter username");
			us=sc.next();
			System.out.println(" Enter Password");
			pass=sc.next();
			dout.writeObject(us);
			dout.writeObject(pass);
			String t=(String)din.readObject();
			//System.out.println(t);
			if(t.equals("Welcome"))
			{
				Customer h=new Customer();
				h=(Customer)din.readObject();
				System.out.println("Welcome "+h.getname());
				LinkedList<hotel> v=(LinkedList<hotel>)din.readObject();
				h.login(v);
				System.out.println("logged out on client side "+h.getUsername());
				dout.writeObject(h);
				
			}
			else
			{
				System.out.println(t);
			}
			
			break;
			
		}
		default:
		{
			break;
		}
		
		}
		}

	}
	
	
	

